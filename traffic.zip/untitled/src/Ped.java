import processing.core.PApplet;
public class Ped extends Floater{
    public Ped(PApplet applet_){
        super(applet_);

    }
}
